 /*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 * All rights reserved.
 *
 * This source code is licensed under the license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @flow
 */

import {AbstractCrudObject} from './../abstract-crud-object';

/**
 * AdCreativeSourcingSpec
 * @extends AbstractCrudObject
 * @see {@link https://developers.facebook.com/docs/marketing-api/}
 */
export default class AdCreativeSourcingSpec extends AbstractCrudObject {
  static get Fields (): Object {
    return Object.freeze({
      ad_extensions_relevancy_spec: 'ad_extensions_relevancy_spec',
      associated_product_set_id: 'associated_product_set_id',
      brand: 'brand',
      destination_screenshot_spec: 'destination_screenshot_spec',
      duplication_source: 'duplication_source',
      dynamic_site_links_spec: 'dynamic_site_links_spec',
      enable_social_feedback_preservation: 'enable_social_feedback_preservation',
      featured_offering_spec: 'featured_offering_spec',
      intent: 'intent',
      ncs_testimonial: 'ncs_testimonial',
      pca_spec: 'pca_spec',
      product_media_metadata_spec: 'product_media_metadata_spec',
      promotion_metadata_spec: 'promotion_metadata_spec',
      site_links_data_consented: 'site_links_data_consented',
      site_links_spec: 'site_links_spec',
      source_url: 'source_url',
      website_media_spec: 'website_media_spec',
      website_summary_spec: 'website_summary_spec',
    });
  }

}

 /*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 * All rights reserved.
 *
 * This source code is licensed under the license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @flow
 */

import {AbstractCrudObject} from './../abstract-crud-object';

/**
 * AdCreativeWAMOWhatsAppIdentitySpec
 * @extends AbstractCrudObject
 * @see {@link https://developers.facebook.com/docs/marketing-api/}
 */
export default class AdCreativeWAMOWhatsAppIdentitySpec extends AbstractCrudObject {
  static get Fields (): Object {
    return Object.freeze({
      wamo_whatsapp_identity_id: 'wamo_whatsapp_identity_id',
      whatsapp_phone_number: 'whatsapp_phone_number',
    });
  }

}
